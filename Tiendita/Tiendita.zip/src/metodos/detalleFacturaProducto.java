package metodos;

public class detalleFacturaProducto {
    public m_productos producto;
    public int cantidad;
}
