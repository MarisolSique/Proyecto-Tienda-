package metodos;

import java.util.Vector;

public class m_facturasProductos {
    /**
     * @attribute
     */
    private int id_factura;

    /**
     * @attribute
     */
    private int cantidad;

    /**
     * @attribute
     */
    private float precio_unitario;

    /**
     * @attribute
     */
    private int id_producto;


    private Boolean limpiarProductosEnFactura(Integer fid) {
        return null;
    }


    public Boolean eliminarProductosEnFactura(Integer fid, Vector lista_productos) {
        return null;
    }

    public Vector obtenerProductosEnFactura(Integer fid) {
        return null;
    }

    public Boolean agregarProductosAFactura(Integer fid, Vector lista_productos) {
        return null;
    }

    public Boolean actualizarProductosEnFactura(Integer fid, Vector lista_productos) {
        return null;
    }
}
