package metodos;

import java.util.Vector;

public class m_persona {
    /**
     * @attribute
     */
    private int id;

    public Integer agregarPersona(String nombre, String correo, String direccion, String telefono) {
        return null;
    }


    public Boolean eliminarPersona(Integer pid) {
        return null;
    }

    public Boolean editarPersona(Integer pid, String nombre, String correo, String direccion, String telefono) {
        return null;
    }

    public Vector obtenerPersona(Integer pid) {
        return null;
    }
}
