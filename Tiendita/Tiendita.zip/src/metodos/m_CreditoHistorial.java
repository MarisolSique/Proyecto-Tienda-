package metodos;

import java.text.DateFormat;
import java.util.Vector;

public class m_CreditoHistorial {


    public Boolean agregarHistorico(Integer factura_id, Boolean transaccion, Float valor, DateFormat fecha) {
        return null;
    }

    public Vector obtenerHistorico(Integer cid) {
        return null;
    }
}
